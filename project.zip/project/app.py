from flask import Flask, render_template, request, redirect, url_for, session
from flask_restful import Api, Resource
from flask_oauthlib.client import OAuth
import os

app = Flask(__name__)
api = Api(app)
app.secret_key = 'supersecretkey'  # Change this to a random secret key

# Configure Google OAuth
oauth = OAuth(app)

google = oauth.remote_app(
    'google',
    consumer_key='YOUR_CLIENT_ID',
    consumer_secret='YOUR_CLIENT_SECRET',
    request_token_params={
        'scope': 'email',
    },
    base_url='https://www.googleapis.com/oauth2/v1/',
    request_token_url=None,
    access_token_method='POST',
    access_token_url='https://accounts.google.com/o/oauth2/token',
    authorize_url='https://accounts.google.com/o/oauth2/auth',
)

# Throttle decorator
def throttle(func):
    def wrapper(*args, **kwargs):
        ip = request.remote_addr
        timestamp = datetime.now()
        if ip not in tokens:
            tokens[ip] = {'count': 0, 'timestamp': timestamp}
        elif (timestamp - tokens[ip]['timestamp']).seconds >= 60:
            tokens[ip] = {'count': 0, 'timestamp': timestamp}
        if tokens[ip]['count'] < THROTTLE_LIMIT:
            tokens[ip]['count'] += 1
            return func(*args, **kwargs)
        return {'message': 'API rate limit exceeded'}, 429

    return wrapper

# In-memory token storage (for simplicity)
tokens = {}

# Throttle limit
THROTTLE_LIMIT = 5

# Token expiration time
TOKEN_EXPIRATION = 600  # seconds (10 minutes)

# Route for Google login
@app.route('/login')
def login():
    return google.authorize(callback=url_for('authorized', _external=True))


# Callback after Google has authorized the user
@app.route('/login/authorized')
def authorized():
    resp = google.authorized_response()
    if resp is None or resp.get('access_token') is None:
        return 'Access denied: reason={} error={}'.format(
            request.args['error_reason'],
            request.args['error_description']
        )
    
    session['google_token'] = (resp['access_token'], '')
    user_info = google.get('userinfo')
    session['user_info'] = user_info.data

    return 'Logged in as: ' + user_info.data['email']

# Get user info from session
@google.tokengetter
def get_google_oauth_token():
    return session.get('google_token')

class Upload(Resource):
    @throttle
    def post(self):
        file = request.files['file']
        if file:
            filename = file.filename
            file.save(os.path.join('static/uploads', filename))  # Save the file
            return redirect(url_for('result', filename=filename))
        return {'message': 'No file uploaded'}, 400

class Result(Resource):
    def get(self, filename):
        return render_template('result.html', filename=filename)

class ViewImage(Resource):
    def get(self, filename):
        return render_template('view.html', filename=filename)

api.add_resource(Upload, '/upload')
api.add_resource(Result, '/result/<string:filename>')
api.add_resource(ViewImage, '/view/<string:filename>')

@app.route('/')
def index():
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(debug=True)
