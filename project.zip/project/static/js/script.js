document.addEventListener('DOMContentLoaded', function() {
    var image = document.getElementById('uploaded-image');
    var zoomBox = document.getElementById('zoom-box');

    image.addEventListener('mousemove', function(e) {
        var rect = image.getBoundingClientRect();
        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;

        var zoomFactor = 2; // Adjust this value for desired zoom level

        var zoomX = x - zoomBox.offsetWidth / (2 * zoomFactor);
        var zoomY = y - zoomBox.offsetHeight / (2 * zoomFactor);

        zoomBox.style.backgroundImage = 'url(' + image.src + ')';
        zoomBox.style.backgroundPosition = -zoomX * zoomFactor + 'px ' + -zoomY * zoomFactor + 'px';
        zoomBox.style.display = 'block';
    });

    image.addEventListener('mouseout', function() {
        zoomBox.style.display = 'none';
    });
});
